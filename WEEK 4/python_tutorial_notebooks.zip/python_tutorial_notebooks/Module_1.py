def welcome():
    return 'Welcome to Python Module';

def summation(a, b):
    return a+b;

def subtraction(a, b):
    return a+b;

def multiplication(a,b):
    return a*b;

def division(a,b):
    return a/b;

def greater_or_equal(a,b):
    if(a>=b):
        return a;
    else:
        return b;
